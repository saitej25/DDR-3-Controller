make compile
make run
make view
