make clean
make lib
make analyze
